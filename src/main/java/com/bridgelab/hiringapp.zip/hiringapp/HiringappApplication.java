package com.bridgelab.hiringapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HiringappApplication {

	public static void main(String[] args) {
		SpringApplication.run(HiringappApplication.class, args);
	}

}
