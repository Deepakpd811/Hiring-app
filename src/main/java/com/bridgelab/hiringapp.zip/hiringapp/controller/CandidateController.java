package com.bridgelab.hiringapp.controller;

import com.bridgelab.hiringapp.dto.ApiSuccessResponseDto;
import com.bridgelab.hiringapp.dto.CandidateDto;
import com.bridgelab.hiringapp.dto.StatusUpdateDto;
import com.bridgelab.hiringapp.entity.Candidate;
import com.bridgelab.hiringapp.service.CandidateService;
import com.bridgelab.hiringapp.utils.BuildResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


//GET /api/candidates/hired
//● GET /api/candidates/{id}
//        ● GET /api/candidates/count

@RestController
@RequestMapping("/api/candidates")
public class CandidateController {

    @Autowired
    private CandidateService candidateService;

    @GetMapping("/")
    public ResponseEntity<ApiSuccessResponseDto> getallcandidate(HttpServletRequest request) {
        List<Candidate> data = candidateService.getCandidateData();
        return BuildResponse.success(data, "List of all Candidates", request.getRequestURI());
    }

    @GetMapping("/{id}")
    public ResponseEntity<ApiSuccessResponseDto> getCandidateById(HttpServletRequest request,
    @PathVariable Long id) {
        Candidate data = candidateService.getCandidateDataById(id);
        return BuildResponse.success(data, "Candidates by id", request.getRequestURI());
    }

    @GetMapping("/count")
    public ResponseEntity<ApiSuccessResponseDto> getCountOfCandidate(HttpServletRequest request) {
        int data = candidateService.getTotalCount();
        return BuildResponse.success(data, "total count", request.getRequestURI());
    }

    @GetMapping("/hired")
    public ResponseEntity<ApiSuccessResponseDto> hiredCandidate(HttpServletRequest request) {
        List<Candidate> data = candidateService.hiredCandidate();

        return BuildResponse.success(data,
                "Hired candidate",
                request.getRequestURI());
    }

    @PostMapping("/create")
    public ResponseEntity<ApiSuccessResponseDto> createCandidate(HttpServletRequest request,
                                                                 @RequestBody CandidateDto dto) {
        Candidate data = candidateService.createCandidateData(dto);
        return BuildResponse.success(data,
                "Candidate created" ,
                request.getRequestURI());
    }

    // status update
    @PutMapping("{id}/status")
    public ResponseEntity<ApiSuccessResponseDto> updateStatusById(HttpServletRequest request,
                                                                  @RequestBody StatusUpdateDto statusDto,
                                                                  @PathVariable Long id) {
        Candidate data = candidateService.updateStatusByid(id,request.getRequestURI(), statusDto);
        return BuildResponse.success(data,
                "Status is updated successfully",
                request.getRequestURI());
    }






}
