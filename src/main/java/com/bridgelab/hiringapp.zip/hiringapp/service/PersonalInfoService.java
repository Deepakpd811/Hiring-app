package com.bridgelab.hiringapp.service;

import org.springframework.stereotype.Service;

@Service
public class PersonalInfoService {

    //

}
