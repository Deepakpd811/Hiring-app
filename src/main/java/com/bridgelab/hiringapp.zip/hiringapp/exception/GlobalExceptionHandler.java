package com.bridgelab.hiringapp.exception;

import com.bridgelab.hiringapp.dto.ApiErrorResponseDto;
import com.bridgelab.hiringapp.dto.ApiSuccessResponseDto;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ControllerAdvice
public class GlobalExceptionHandler {


    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponseDto> handleValidationExceptions(
            MethodArgumentNotValidException ex,
            HttpServletRequest request
    ) {
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getFieldErrors().forEach(error ->
                errors.put(error.getField(), error.getDefaultMessage())
        );

        ApiErrorResponseDto response = ApiErrorResponseDto.builder()
                .timestamp(LocalDateTime.now().toString())
                .status(HttpStatus.BAD_REQUEST.toString())
                .message("Validation failed")
                .error("Bad Request")
                .path(request.getRequestURI())
                .build();

        return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
    }



    @ExceptionHandler
    public ResponseEntity<ApiErrorResponseDto> CandidateNotFoundException(CandidateNotFoundException ex) {

        ApiErrorResponseDto err = ApiErrorResponseDto.builder()
                .error("Candidate not found")
                .message("Candidate with id " + ex.getId() + " does not exist")
                .status(HttpStatus.NOT_FOUND.toString())
                .path(ex.getPath())
                .timestamp(LocalTime.now().toString())
                .build();


        return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
    }

}
