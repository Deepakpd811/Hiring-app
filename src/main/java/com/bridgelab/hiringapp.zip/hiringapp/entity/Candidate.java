package com.bridgelab.hiringapp.entity;

import com.bridgelab.hiringapp.dto.CandidateDto;
import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;


@Data
@Entity
@NoArgsConstructor
@Table(name = "candidate")
public class Candidate {


    public enum Status {
        APPLIED, INTERVIEWED, OFFERED, ONBOARDED
    }

    public enum OnboardStatus {
        NOT_STARTED, IN_PROGRESS, COMPLETE
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "first_name", nullable = false, length = 50)
    private String firstName;

    @Column(name = "last_name", nullable = false, length = 50)
    private String lastName;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(name = "phone_number", nullable = false, length = 20)
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Status status = Status.APPLIED;

    @Enumerated(EnumType.STRING)
    @Column(name = "onboard_status", nullable = false)
    private OnboardStatus onboardStatus = OnboardStatus.NOT_STARTED;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false, columnDefinition = "DATETIME")
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at", columnDefinition = "DATETIME")
    private LocalDateTime updatedAt;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "personalInfo_id")
    private PersonalInfo personalInfo;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "bank_info_id")
    private BankInfo bankInfo;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "education_id")
    private Education education;

    public Candidate(CandidateDto dto){
        this.firstName = dto.getFirstName();
        this.lastName = dto.getLastName();
        this.status = getStatus();
        this.phoneNumber = dto.getPhoneNumber();
        this.onboardStatus = dto.getOnboardStatus();
        this.email = dto.getEmail();
    }

}
