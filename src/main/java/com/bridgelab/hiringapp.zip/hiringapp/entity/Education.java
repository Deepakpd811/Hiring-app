package com.bridgelab.hiringapp.entity;


import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@Table(name = "education_info")
public class Education {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(mappedBy = "education_info")
    private Candidate candidate;

    @Column(nullable = false, length = 30)
    private String degree;

    @Column(nullable = false, length = 30)
    private String institution;

    @Column(nullable = false, length = 30)
    private int yearOfPassing;


}
