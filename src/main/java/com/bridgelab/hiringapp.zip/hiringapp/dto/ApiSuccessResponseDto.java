package com.bridgelab.hiringapp.dto;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ApiSuccessResponseDto {
    private String timestamp;
    private String status;
    private String message;
    private String path;
    private Object data;
}
