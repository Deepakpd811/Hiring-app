package com.bridgelab.hiringapp.dto;


//{
//        "timestamp": "2025-05-05T14:23:00",
//        "status": 404,
//        "error": "Candidate Not Found",
//        "message": "Candidate with ID 12 does not exist",
//        "path": "/api/candidates/12"
//        }

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ApiErrorResponseDto {

    private String timestamp;
    private String status;
    private String message;
    private String path;
    private String error;

}
